.. _miscellaneous:

=================
 Miscellaneous
=================

.. toctree::
   :maxdepth: 2

   ../aboutus.rst
   ../citing.rst
   ../wiki.rst
   ../outreach.rst
