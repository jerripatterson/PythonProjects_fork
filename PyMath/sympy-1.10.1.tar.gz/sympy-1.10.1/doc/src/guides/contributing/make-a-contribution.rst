Making a Contribution
======================

For in-depth instructions on how to contribute to SymPy’s code base including
coding conventions, creating your environment, picking an issue to fix, and
opening a pull request, please read our full `Development Workflow
<https://github.com/sympy/sympy/wiki/Development-workflow>`_ guide.
