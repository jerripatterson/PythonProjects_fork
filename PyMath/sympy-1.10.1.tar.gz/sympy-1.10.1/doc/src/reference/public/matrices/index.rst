.. _matrices_modules:

========
Matrices
========

**Contents**

.. toctree::
    :maxdepth: 2

    ../../../modules/matrices/index.rst
    ../../../modules/tensor/index.rst
    ../../../modules/vector/index.rst
    