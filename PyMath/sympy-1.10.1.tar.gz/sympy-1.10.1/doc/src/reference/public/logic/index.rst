.. _logic:

======
Logic
======

**Contents**

.. toctree::
    :maxdepth: 2

    ../../../modules/logic.rst
    ../../../modules/sets.rst
    