.. _codegen_module:

===============
Code Generation
===============

**Contents**

.. toctree::
    :maxdepth: 2

    ../../../modules/codegen.rst
