Plane
-----

.. module:: sympy.geometry.plane

.. autoclass:: Plane
   :members:
