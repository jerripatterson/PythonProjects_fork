========
Matrices
========

.. automodule:: sympy.physics.matrices
   :members:
