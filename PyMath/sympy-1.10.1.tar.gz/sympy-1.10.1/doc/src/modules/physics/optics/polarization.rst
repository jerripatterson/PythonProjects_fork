============
Polarization
============

.. automodule:: sympy.physics.optics.polarization
   :members:
