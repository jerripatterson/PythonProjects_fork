==================================
Quantum Harmonic Oscillator in 3-D
==================================

.. automodule:: sympy.physics.sho
   :members:
