.. _matrices-normalforms:

===================
Matrix Normal Forms
===================

.. currentmodule:: sympy.matrices.normalforms

.. autofunction:: smith_normal_form
.. autofunction:: hermite_normal_form
