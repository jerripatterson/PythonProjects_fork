=======================
Exceptions and Warnings
=======================

.. automodule:: sympy.utilities.exceptions
   :members:
