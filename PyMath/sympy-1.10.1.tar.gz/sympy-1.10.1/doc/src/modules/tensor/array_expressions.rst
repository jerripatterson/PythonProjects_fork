=======================
N-dim array expressions
=======================

.. automodule:: sympy.tensor.array.expressions
