=======
Methods
=======

.. automodule:: sympy.tensor.index_methods
   :members:
