.. _inequality-docs:

Inequality Solvers
==================

.. module:: sympy.solvers.inequalities

.. autofunction:: solve_rational_inequalities

.. autofunction:: solve_poly_inequality

.. autofunction:: solve_poly_inequalities

.. autofunction:: reduce_rational_inequalities

.. autofunction:: reduce_abs_inequality

.. autofunction:: reduce_abs_inequalities

.. autofunction:: reduce_inequalities

.. autofunction:: solve_univariate_inequality
