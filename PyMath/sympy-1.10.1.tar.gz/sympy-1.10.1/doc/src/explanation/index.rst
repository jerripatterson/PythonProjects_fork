.. _explanation:

=============
 Explanation
=============

This section contains a discussion of in-depth feature details, specialized topics and common SymPy pitfalls.

**Content**

.. toctree::
   :maxdepth: 2

   gotchas.rst
   special_topics/index.rst
   active-deprecations.md
