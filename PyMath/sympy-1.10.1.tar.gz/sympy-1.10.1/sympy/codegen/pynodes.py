from .abstract_nodes import List as AbstractList

class List(AbstractList):
    pass
